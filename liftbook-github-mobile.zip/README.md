# Liftbook – Gym Progress Tracker
All files sit in one folder so they can be uploaded from a phone.
Upload all 7 files to the repository root, then turn on
Settings → Pages → Deploy from a branch → main → / (root).
Live link: https://<your-username>.github.io/<repo-name>/
