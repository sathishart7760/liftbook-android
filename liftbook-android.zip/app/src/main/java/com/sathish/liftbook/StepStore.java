package com.sathish.liftbook;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Turns the phone's cumulative step counter into steps per day. */
public final class StepStore {
    private static final String PREFS = "liftbook_steps";

    private StepStore() { }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** counter = total steps since the phone last booted (TYPE_STEP_COUNTER). */
    public static synchronized void record(Context c, long counter) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long last = p.getLong("last", -1);
        String day = today();
        try {
            JSONObject map = new JSONObject(p.getString("map", "{}"));
            long delta;
            if (last < 0) delta = 0;               // first reading = starting point
            else if (counter < last) delta = counter; // phone rebooted, counter restarted
            else delta = counter - last;
            if (delta > 0 && delta < 100000) map.put(day, map.optLong(day, 0) + delta);
            else if (!map.has(day)) map.put(day, 0);
            prune(map);
            SharedPreferences.Editor ed = p.edit().putLong("last", counter).putLong("readAt", System.currentTimeMillis()).putString("map", map.toString());
            if (last < 0) ed.putLong("enabledAt", System.currentTimeMillis());
            ed.apply();
        } catch (Exception ignored) { }
    }

    public static synchronized String json(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("map", "{}");
    }

    public static synchronized long raw(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("last", -1);
    }

    public static synchronized String info(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return "{\"enabledAt\":" + p.getLong("enabledAt", 0) + ",\"readAt\":" + p.getLong("readAt", 0) + ",\"raw\":" + p.getLong("last", -1) + "}";
    }

    private static void prune(JSONObject map) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -370);
        String cutoff = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
        List<String> old = new ArrayList<>();
        Iterator<String> it = map.keys();
        while (it.hasNext()) { String k = it.next(); if (k.compareTo(cutoff) < 0) old.add(k); }
        for (String k : old) map.remove(k);
    }
}
