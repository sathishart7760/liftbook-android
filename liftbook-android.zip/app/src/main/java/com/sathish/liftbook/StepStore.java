package com.sathish.liftbook;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Turns the phone's cumulative step counter into steps per day and per hour. */
public final class StepStore {
    private static final String PREFS = "liftbook_steps";

    private StepStore() { }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    /** counter = total steps since the phone last booted (TYPE_STEP_COUNTER). */
    public static synchronized void record(Context c, long counter) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long boot = now - SystemClock.elapsedRealtime();
        long last = p.getLong("last", -1);
        long lastBoot = p.getLong("boot", 0);
        long lastAt = p.getLong("readAt", 0);
        boolean rebooted = lastBoot > 0 && Math.abs(boot - lastBoot) > 120000;
        String day = today();
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        try {
            long delta;
            if (last < 0) delta = 0;                    // first reading = starting point
            else if (rebooted) delta = counter;         // phone restarted: counter began again at 0
            else if (counter < last) delta = 0;         // sensor glitch: just move the starting point
            else delta = counter - last;
            // Sanity limit: nobody walks faster than about 4 steps a second.
            if (lastAt > 0 && delta > 0) {
                long sec = Math.max(1, (now - lastAt) / 1000);
                long max = sec * 4 + 30;
                if (delta > max) delta = max;
            }

            JSONObject map = new JSONObject(p.getString("map", "{}"));
            JSONObject hours = new JSONObject(p.getString("hours", "{}"));
            if (delta > 0) {
                map.put(day, map.optLong(day, 0) + delta);
                JSONArray h = hours.optJSONArray(day);
                if (h == null || h.length() != 24) { h = new JSONArray(); for (int i = 0; i < 24; i++) h.put(0); }
                h.put(hour, h.optLong(hour, 0) + delta);
                hours.put(day, h);
            } else if (!map.has(day)) {
                map.put(day, 0);
            }
            prune(map, 370);
            prune(hours, 14);

            SharedPreferences.Editor ed = p.edit()
                    .putLong("last", counter)
                    .putLong("boot", boot)
                    .putLong("readAt", now)
                    .putString("map", map.toString())
                    .putString("hours", hours.toString());
            if (last < 0) ed.putLong("enabledAt", now);
            ed.apply();
        } catch (Exception ignored) { }
    }

    public static synchronized String json(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("map", "{}");
    }

    public static synchronized String hours(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("hours", "{}");
    }

    public static synchronized long raw(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("last", -1);
    }

    public static synchronized String info(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return "{\"enabledAt\":" + p.getLong("enabledAt", 0) + ",\"readAt\":" + p.getLong("readAt", 0) + ",\"raw\":" + p.getLong("last", -1) + "}";
    }

    private static void prune(JSONObject map, int days) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -days);
        String cutoff = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
        List<String> old = new ArrayList<>();
        Iterator<String> it = map.keys();
        while (it.hasNext()) { String k = it.next(); if (k.compareTo(cutoff) < 0) old.add(k); }
        for (String k : old) map.remove(k);
    }
}
