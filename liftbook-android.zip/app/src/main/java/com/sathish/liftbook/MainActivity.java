package com.sathish.liftbook;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.OutputStream;

public class MainActivity extends Activity implements SensorEventListener {

    private static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int REQ_PICK_FILE = 1;
    private static final int REQ_SAVE_FILE = 2;
    private static final int REQ_STEPS = 3;
    private SensorManager sensors;
    private Sensor stepSensor;
    private long lastNotify = 0;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] pendingSave;
    private Uri cameraUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0F1217);
        setContentView(web);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equals(uri.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                cameraUri = null;
                String[] accept = params.getAcceptTypes();
                boolean image = accept != null && accept.length > 0 && accept[0] != null && accept[0].startsWith("image");

                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(image ? "image/*" : "*/*");

                Intent camera = image ? cameraIntent() : null;
                try {
                    if (camera != null && params.isCaptureEnabled()) {
                        // "Scan food": open the camera straight away.
                        startActivityForResult(camera, REQ_PICK_FILE);
                    } else {
                        Intent chooser = Intent.createChooser(pick, image ? "Take or choose a photo" : "Choose a tracker .xlsx or backup .json");
                        if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{ camera });
                        startActivityForResult(chooser, REQ_PICK_FILE);
                    }
                } catch (Exception e) {
                    try {
                        cameraUri = null;
                        startActivityForResult(Intent.createChooser(pick, "Choose a file"), REQ_PICK_FILE);
                    } catch (Exception e2) {
                        fileCallback = null;
                        return false;
                    }
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "Android");

        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        stepSensor = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (stepsAllowed()) StepJob.schedule(this);

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(START_URL);
    }

    /** Functions the web app can call as window.Android.* */
    private class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, String base64) {
            pendingSave = Base64.decode(base64, Base64.DEFAULT);
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mimeFor(name));
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE_FILE);
                } catch (ActivityNotFoundException e) {
                    pendingSave = null;
                    jsToast("No file manager found to save the file");
                }
            });
        }

        @JavascriptInterface
        public boolean stepsSupported() { return stepSensor != null; }

        @JavascriptInterface
        public boolean stepsAllowed() { return MainActivity.this.stepsAllowed(); }

        @JavascriptInterface
        public String getSteps() { return StepStore.json(MainActivity.this); }

        @JavascriptInterface
        public long rawSteps() { return StepStore.raw(MainActivity.this); }

        @JavascriptInterface
        public String getStepHours() { return StepStore.hours(MainActivity.this); }

        @JavascriptInterface
        public String stepsInfo() { return StepStore.info(MainActivity.this); }

        @JavascriptInterface
        public void requestSteps() {
            runOnUiThread(() -> {
                if (stepSensor == null) { jsToast("This phone has no step sensor"); return; }
                if (MainActivity.this.stepsAllowed()) { startSteps(); return; }
                requestPermissions(new String[]{ Manifest.permission.ACTIVITY_RECOGNITION }, REQ_STEPS);
            });
        }

        @JavascriptInterface
        public void vibrate(long ms) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(ms);
        }
    }

    private boolean stepsAllowed() {
        if (stepSensor == null) return false;
        if (Build.VERSION.SDK_INT < 29) return true;
        return checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startSteps() {
        StepJob.schedule(this);
        if (sensors != null && stepSensor != null) sensors.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        web.evaluateJavascript("window.onNativeSteps && onNativeSteps(true)", null);
        jsToast("Step counting is on");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_STEPS) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startSteps();
        else jsToast("Allow Physical activity in Settings to count steps");
    }

    @Override
    public void onSensorChanged(SensorEvent e) {
        StepStore.record(this, (long) e.values[0]);
        long now = System.currentTimeMillis();
        if (now - lastNotify > 1000) {
            lastNotify = now;
            web.evaluateJavascript("window.onNativeSteps && onNativeSteps()", null);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    /** Camera intent that saves the photo into the app's private cache. Needs no camera permission. */
    private Intent cameraIntent() {
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists() && !dir.mkdirs()) return null;
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 3600000L) f.delete();
            File out = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".files", out);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return i;
        } catch (Exception e) {
            cameraUri = null;
            return null;
        }
    }

    private static String mimeFor(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    private void jsToast(String msg) {
        String safe = msg.replace("\\", "\\\\").replace("'", "\\'");
        web.evaluateJavascript("typeof toast==='function'&&toast('" + safe + "')", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_FILE) {
            if (fileCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                if (resultCode == RESULT_OK && (result == null || result.length == 0) && cameraUri != null) result = new Uri[]{ cameraUri };
                fileCallback.onReceiveValue(resultCode == RESULT_OK ? result : null);
                fileCallback = null;
            }
            cameraUri = null;
        } else if (requestCode == REQ_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSave != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    os.write(pendingSave);
                    jsToast("File saved");
                } catch (Exception e) {
                    jsToast("Couldn't save the file");
                }
            }
            pendingSave = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.liftbookBack ? window.liftbookBack() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (sensors != null) sensors.unregisterListener(this);
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        if (stepsAllowed() && sensors != null) sensors.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_UI);
        web.evaluateJavascript("window.onNativeSteps && onNativeSteps(true)", null);
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
