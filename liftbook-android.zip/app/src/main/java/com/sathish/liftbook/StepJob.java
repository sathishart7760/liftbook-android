package com.sathish.liftbook;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;

/** Wakes up about every 15 minutes, reads the step counter once and stores the new steps. */
public class StepJob extends JobService {
    private static final int JOB_ID = 4711;

    public static void schedule(Context c) {
        JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (js == null || js.getPendingJob(JOB_ID) != null) return;
        JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(c, StepJob.class))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .build();
        try { js.schedule(info); } catch (Exception ignored) { }
    }

    @Override
    public boolean onStartJob(final JobParameters params) {
        final SensorManager sm = (SensorManager) getSystemService(SENSOR_SERVICE);
        final Sensor sensor = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (sensor == null) return false;
        final Handler h = new Handler(Looper.getMainLooper());
        final boolean[] done = { false };
        final SensorEventListener[] holder = new SensorEventListener[1];
        final Runnable finish = () -> {
            if (done[0]) return;
            done[0] = true;
            sm.unregisterListener(holder[0]);
            jobFinished(params, false);
        };
        holder[0] = new SensorEventListener() {
            @Override public void onSensorChanged(SensorEvent e) {
                StepStore.record(StepJob.this, (long) e.values[0]);
                h.post(finish);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) { }
        };
        sm.registerListener(holder[0], sensor, SensorManager.SENSOR_DELAY_NORMAL);
        h.postDelayed(finish, 10000);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
